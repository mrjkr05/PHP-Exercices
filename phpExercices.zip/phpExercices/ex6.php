<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Exercice 6</title>
	<script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
        <div class="container text-center">
			<h2>Exercice 6</h2>
			      <h2><a href="index.php">Get back to the main page</a></h2>
            <div class="row">
                <form action="" method="GET" >
                	<div class="contenu">
	                    <p>Prix HT  : <input id="input1" name="input1"></p>
	                    <p>Taux TVA : <input id="input2" name="input2"></p>
                	<button type="submit" name="cal">Affiche</button>
                </form>
 
            </div>
 
            <div class="row">
                <p class="resultat"></p>
            </div>
 
        </div>
</body>
</html>

<?php 


if (isset($_GET['input1']) && isset($_GET['input2']) && isset($_GET['cal'])) {
	
	$pttc = $_GET['input1'] * ( $_GET['input2'] / 100) + $_GET['input1'];
	
	echo "<p class='text-center'> <div> le prix hors taxe est ".$_GET['input1']." MAD</div><div> la TVA est ".$_GET['input2']." MAD</div><div> le prix de vemte est ".$pttc." MAD</div></p>";



/*Le script affiche le
montant de la TVA et le prix TTC dans deux zones de texte créées dynamiquement. Le formulaire
maintient les données saisies. */


	
}
 ?>