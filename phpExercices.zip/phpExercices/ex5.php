<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Exercice 5</title>
	<script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
        <div class="container text-center">
			      <h2>Exercice 5</h2>
			      <h2><a href="index.php">Get back to the main page</a></h2>
            <div class="row">
                <form action="" method="GET" >
                	<div class="contenu">
	                    <p>email : <input type="email" name="input1" id="input1"></p>
	                    <p>Get the name of the browser : <input type="checkbox" name="input2" id="input2"></p>
                	</div>
                	<button type="submit" name="affiche" id="btn">Affiche la table de multplication</button>
                </form>
            </div>
 
 
        </div>
</body>
</html>
<?php 
$t = explode(';', $_SERVER['HTTP_SEC_CH_UA'])[0];

if(isset($_GET["input1"])){
	$show = "<p class='text-center'> your adresse mail is ".$_GET['input1'];
	if ($_GET["input2"]) {
		$show.="<br> your browser is ".$t."</p>";
	}else{
		$show.= "</p>";
	}
	echo "$show";
}

 ?>