<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Exercice 1</title>
	<script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
        <div class="container text-center">
			<h2>CALCULATRICE</h2>
			      <h2><a href="index.php">Get back to the main page</a></h2>
            <div class="row">
                <form action="" method="GET" >
                	<div class="contenu">
	                    <p>Valeur 1 : <input id="input1" name="input1"></p>
	                    <p>Valeur 2 : <input id="input2" name="input2"></p>
	                    <select name="operation">
	                        <option value="+" >+</option>
	                        <option value="-" >-</option>
	                        <option value="*" >x</option>
	                        <option value="/" >/</option>
	                    </select>
                	</div>
                	<button type="submit" name="cal">Calculer</button>
                </form>
 
            </div>
 
            <div class="row">
                <p class="resultat"></p>
            </div>
 
        </div>
</body>
</html>

<?php 


if (isset($_GET['input1']) && isset($_GET['input2']) && isset($_GET['operation']) && isset($_GET['cal'])) {
	$result;

	switch ($_GET['operation']) {
	    case '+':
	        $result = $_GET['input1'] + $_GET['input2'];
			echo "<p class='text-center'> the addition of<br>". $_GET['input1'] ." + ".$_GET['input2']." = ".$result." </p>";
	        break;
	    case '-':
	        $result = $_GET['input1'] - $_GET['input2'];
			echo "<p class='text-center'> the subsraction of<br>". $_GET['input1'] ." - ".$_GET['input2']." = ".$result." </p>";
	        break;
	    case '*':
	        $result = $_GET['input1'] * $_GET['input2'];
			echo "<p class='text-center'> the multiplication of<br>". $_GET['input1'] ." * ".$_GET['input2']." = ".$result." </p>";
	        break;
	    case '/':
	        if ($_GET['input2'] != 0) {
				$result = $_GET['input1'] / $_GET['input2'];
				echo "<p class='text-center'> the deviation of<br>". $_GET['input1'] ." / ".$_GET['input2']." = ".$result." </p>";
			}else{
				echo "<p class='text-center'> the deviation on 0 is an error</p>";
			}
	        break;
	    default :
			echo "<p class='text-center'> something went wrong</p>";
	    	break;
}


	
}
 ?>