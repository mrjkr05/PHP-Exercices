<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Exercice 3</title>
	<script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
        <div class="container text-center">
			      <h2>Exercice 3</h2>
            <h2><a href="index.php">Get back to the main page</a></h2>
            <div class="row">
                <form action="" method="GET" >
                	<div class="contenu">
	                    <p>Number 1 : <input name="input1"></p>
	                    <p>Number 2 : <input name="input2"></p>
	                    
                	</div>
                	<button type="submit" name="affiche">Affiche la table de multplication</button>
                </form>
 
            </div>
 
 
        </div>
</body>
</html>
<?php 


if (isset($_GET['input1']) && isset($_GET['input2']) && isset($_GET['affiche'])) {
  for ($i=1; $i <= $_GET['input2'] ; $i++) { 
    echo "<div> ".$_GET['input1']. " * ".$i."=".$i * $_GET['input1']."</div>";
  }
}

