<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Exercice 7</title>
	<script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
        <div class="container text-center">
			<h2>Exercice 7</h2>
			      <h2><a href="index.php">Get back to the main page</a></h2>
            <div class="row">
                <form action="" method="POST" enctype="multipart/form-data">
                	<div class="contenu">
	                    <p>Load the file : <input id="input1" type="file" name="input1" accept=".zip" size="1" max-file-size="1024" total-max-size="1024"></p>
                	</div>
            		<button type="submit">Send</button>
                </form>
 
            </div>
 
        </div>
</body>
</html>

<?php 


if(isset($_POST)){
        $file_plase = "input1/";
        $rslt = "";
        $my_file_type = $_FILES['input1']['type'];
        if($my_file_type == "application/x-zip-compressed"){
            if($_FILES['input1']['size'] > 1000000){
                $rslt = "This file is so big <br>".
                "max 1 M oct";


            }else{
                  $rslt = "the file name : ".$_FILES["input1"]["name"]."<br>".
                    "the file size : ".$_FILES['input1']['size']."oct <br>";
            }

        }else{
            $rslt = "the file is not zip <br> your file is :";
        }


    }
    ?>
    <p><?php if(isset($rslt)){echo $rslt;
    
    } ?></p>
