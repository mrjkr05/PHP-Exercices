<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<a href="ex1.php">Exercice 1</a>
	<a href="ex2.php">Exercice 2</a>
	<a href="ex3.php">Exercice 3</a>
	<a href="ex4.php">Exercice 4</a>
	<a href="ex5.php">Exercice 5</a>
	<a href="ex6.php">Exercice 6</a>
	<a href="ex7.php">Exercice 7</a>
	<a href="ex8.php">Exercice 8</a>
</body>
</html>