
			      <h2><a href="index.php">Get back to the main page</a></h2>
			      <h2><a href="ex2.php">Get back to the previus page</a></h2>
<?php 


if (isset($_GET['input1']) && isset($_GET['affiche']) && ( isset($_GET['input2']) || isset($_GET['input3']))) {
	$result = "<p class='text-center'> Bonjour";
	if (isset($_GET['input2'])) {
		$result .= " Mr ". $_GET["input1"];
	}elseif (isset($_GET['input3'])) {
		$result .= " Mme ". $_GET["input1"];
	}else{
		$result.= " something went wrong</p>";
	}
	echo "$result";

}
 ?>