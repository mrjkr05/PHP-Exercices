<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Exercice 8</title>
	<script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
        <div class="container text-center">
			<h2>CALCULATRICE</h2>
			      <h2><a href="index.php">Get back to the main page</a></h2>
            <div class="row">
                <form action="" method="GET" >
                	<div class="contenu">
	                    
	                	<button type="submit" name="vendre">Vendre</button>
	                	<button type="submit" name="acheter">Acheter</button>
                		<button type="submit" name="louer">Louer</button>
                	</div>
                </form>
 
            </div>
 
            <div class="row">
                <p class="resultat"></p>
            </div>
 
        </div>
</body>
</html>

<?php 


if (isset($_GET)) {
	if (isset($_GET['vendre'])) {
		header("location: vendre.php");
	} else if(isset($_GET['acheter'])) {
		echo "string";
		header("location: achetre.php");
	} else if(isset($_GET['louer'])) {
		header("location: louer.php");
	}
	
	
}
 ?>