<script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
			      <h2><a href="index.php">Get back to the main page</a></h2>
			      <h2><a href="ex4.php">Get back to the previus page</a></h2>
<?php 
	if (isset($_GET['input1']) && isset($_GET['input2']) && isset($_GET['input3']) && isset($_GET['input4']) && isset($_GET['input5'])) {
		$show = '<table class="table"><thead><tr><th scope="col">Name</th><th scope="col">First Name</th><th scope="col">adresse</th><th scope="col">postal code</th><th scope="col">city</th></tr></thead><tbody><tr><td>'.$_GET['input1'].'</td><td>'.$_GET['input2'].'</td><td>'.$_GET['input3'].'</td><td>'.$_GET['input4'].'</td><td>'.$_GET['input5'].'</td>';
		echo $show;

	}